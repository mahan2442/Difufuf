<?php
declare(strict_types=1);
session_set_cookie_params(['httponly'=>true,'secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off','samesite'=>'Lax']);
session_start();
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
const DB_HOST='localhost';
const DB_NAME='nooshad_school';
const DB_USER='YOUR_DB_USER';
const DB_PASS='YOUR_DB_PASSWORD';
const BASE_URL='';
function db():PDO{static $pdo; if(!$pdo){$pdo=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);}return $pdo;}
function e(?string $v):string{return htmlspecialchars($v??'',ENT_QUOTES,'UTF-8');}
function user():?array{return $_SESSION['user']??null;}
function require_login():void{if(!user()){header('Location: login.php');exit;}}
function require_role(array $roles):void{require_login();if(!in_array(user()['role'],$roles,true)){http_response_code(403);exit('دسترسی مجاز نیست.');}}
function csrf():string{if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(32));return $_SESSION['csrf'];}
function check_csrf():void{if(!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??'')){http_response_code(419);exit('درخواست نامعتبر است.');}}
function redirect(string $to):never{header('Location: '.$to);exit;}
function audit(string $action,?int $target=null,?string $details=null):void{$u=user();$s=db()->prepare('INSERT INTO audit_logs(actor_user_id,target_user_id,action,details,ip) VALUES(?,?,?,?,?)');$s->execute([$u['id']??null,$target,$action,$details,$_SERVER['REMOTE_ADDR']??null]);}
function role_label(string $r):string{return ['owner'=>'مالک','deputy'=>'معاون','teacher'=>'معلم','student'=>'دانش‌آموز'][$r]??$r;}
function can_manage_class(int $classId):bool{if(in_array(user()['role'],['owner','deputy'],true))return true;$s=db()->prepare('SELECT 1 FROM teacher_assignments WHERE teacher_id=? AND class_id=? LIMIT 1');$s->execute([user()['id'],$classId]);return(bool)$s->fetchColumn();}
function student_allowed(int $studentId):bool{if(in_array(user()['role'],['owner','deputy'],true))return true;$s=db()->prepare('SELECT 1 FROM student_classes sc JOIN teacher_assignments ta ON ta.class_id=sc.class_id WHERE sc.student_id=? AND ta.teacher_id=? LIMIT 1');$s->execute([$studentId,user()['id']]);return(bool)$s->fetchColumn();}
function student_allowed_in_class(int $studentId,int $classId):bool{if(in_array(user()['role'],['owner','deputy'],true))return true;$s=db()->prepare('SELECT 1 FROM student_classes sc JOIN teacher_assignments ta ON ta.class_id=sc.class_id WHERE sc.student_id=? AND sc.class_id=? AND ta.teacher_id=? LIMIT 1');$s->execute([$studentId,$classId,user()['id']]);return(bool)$s->fetchColumn();}
